package containers;

public class SmallContainer extends Container {

	public int price;

	public SmallContainer() {
		super(259.0, 243.0, 606.0);
	}
}
