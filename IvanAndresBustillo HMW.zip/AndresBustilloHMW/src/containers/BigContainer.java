package containers;

public class BigContainer extends Container {

	public int price;

	public BigContainer() {
		super(259.0, 243.0, 1201.0);
	}

}
